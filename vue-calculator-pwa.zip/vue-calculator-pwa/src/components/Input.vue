<template>
 <form @submit.prevent="handleSubmit">
  <button
   class='submit-btn'
   :disabled="!isEnabled"
   type="submit"
  >
   Calculate!      
  </button>
 </form>  
</template>
<script>

  computed: {
      isEnabled: function() {
        return !!Object.values(this.inputs).every(Boolean);
      }
    },
    methods: {
      input: function(input) {
        if (input.type === "input") {
         this.incomeValue = input.value;
        }
      },
      handleSubmit: function() {
        const { isInChurch, stateOfResidence } = this.inputs;
        const inputValues = {
          ...this.inputs,
          yearValue: yearValue.value,
          isInChurch: isInChurch.value,
          stateOfResidence: stateOfResidence.value
        };
        this.$emit("submitted", inputValues);
      }
    }
</script>