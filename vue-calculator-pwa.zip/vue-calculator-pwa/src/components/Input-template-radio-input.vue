<template>
 <div
  v-if="type ==='radio'"
  v-for='option in options'
  :key='option.label'>
 <input
  type="radio"
  class="radio"
  :id="option.label"
  :value="option.value"
  :checked="value === option.value"
  @input="customInput($event.target.value)"
  >
   <label :for="option.label">{{option.label}}</label>
  </div>

</template>

<script>

  props: {
    
    value: [String, Object, Boolean]

  }

 </script>