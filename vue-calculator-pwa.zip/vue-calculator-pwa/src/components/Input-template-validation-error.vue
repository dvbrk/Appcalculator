<template>

 <transition name="alert-in"
  enter-active-class="animated flipInX"
  leave-active-class="animated flipOutX">
   <p v-if="validationError" class="alert" >
    {{ validationError }}
   </p>
 </transition>
</template>