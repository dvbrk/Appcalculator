<template>
  <InputForm @submitted="submitted" />

</template>
<script>

import { calcTaxes } from "./calc.js";

export default {

  data() {
    return {
      calculations: {}
    };
  },
  methods: {
    submitted: function(input) {
      const calcValues = calcTaxes(input);

      this.calculations = {
        grossIncome: { label: "Gross Salary", value: calcValues.incomeValue },
        tax: { label: "Income Tax", value: -calcValues.incomeTax },
        churchTax: { label: "Church Tax", value: -calcValues.churchTax },
        soli: { label: "Solidarity Charge", value: -calcValues.soli },
        netIncome: { label: "Net Salary", value: calcValues.netIncome }
      };
    },
  }
};
</script>