<template>
...
 <v-select
      v-if="type ==='dropdown'"
      class="input-dropdown"
      @input="customInput"
      :options="options"
    />
</template>
<script>
...
export default {
...
props {
     ...
     options: Array
}