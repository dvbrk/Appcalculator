
<template>
  <div id="app">
    <main>
    </main>
  </div>
</template>

<script>
import Panel from "./components/Panel.vue";
import InputForm from "./components/InputForm";
import Result from "./components/Result";
import { calcTaxes } from "./calc.js";
export default {
  name: "app",
  components: {
    Panel,
    InputForm,
    Result
  }
};
</script>

<style lang="scss" src="./assets/styles/App.scss"/>

<template>
  <div id="app">
    <main>
      <Panel
        class="calculator-panel"
        headline="Income Tax Calculator"
      >
        <template>
          <transition
            name="alert-in"
            mode="out-in"
            enter-active-class="animated fadeIn"
            leave-active-class="animated fadeOut"
          >
            <InputForm
              v-if="!resultsCalculated"
              @submitted="submitted"
            />
            <Result
              v-if="resultsCalculated"
              @clearCalculations='clearCalculations'
              :results="calculations"
            />
          </transition>
        </template>
      </Panel>
    </main>
  </div>
</template>

<script>
...
export default {
  ...
  data() {
    return {
      calculations: {}
    };
  },
  computed: {
    resultsCalculated: function() {
      return Object.keys(this.calculations).length !== 0;
    }
  },
  methods: {
   ...
   clearCalculations: function() {
    this.calculations = {};
   }
  }
};
</script>
