import vSelect from 'vue-select'

Vue.component('v-select', vSelect)